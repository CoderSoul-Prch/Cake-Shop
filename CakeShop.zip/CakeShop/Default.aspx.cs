﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace CakeShop
{
    public partial class Default : System.Web.UI.Page
    {

        //----------------------//
        //Define Global Varables//
        //----------------------//
        protected string strProductBannerHeading { get; set; }
        protected string InputValue { get; set; }

        SqlConnection conn;

        protected void Page_Load(object sender, EventArgs e)
        {
            //---------------------//
            //Define Local Varables//
            //---------------------//
            string strConn;

            //--------------------//
            //Get ConnectionString//
            //--------------------//
            strConn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString(); // ConfigurationManager.AppSettings.Get("ConnectionString");

            //-----------------------//
            //Set and Open Connection//
            //-----------------------//
            conn = new SqlConnection(strConn);
            conn.Open();

            SqlCommand cmd = new SqlCommand("select * from CakeMaster", conn);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);

            Random RandomRow = new Random();
            int rowno = RandomRow.Next(0, ds.Tables[0].Rows.Count);

            this.imgBanner.ImageUrl = "ProductImg/Banners/" + ds.Tables[0].Rows[rowno]["CakeImageName"].ToString();
            this.strProductBannerHeading = ds.Tables[0].Rows[rowno]["CakeName"].ToString();
            this.lblPrice.Text = "Rs. " + ds.Tables[0].Rows[rowno]["CakePrice"].ToString();
            this.lblDescription.Text = ds.Tables[0].Rows[rowno]["CakeDescription"].ToString();
            this.btnBannerOrder.NavigateUrl = "order.aspx?CakeCode=" + ds.Tables[0].Rows[rowno]["CakeCode"].ToString();
            this.btnBannerOrder.ToolTip = "Order " + ds.Tables[0].Rows[rowno]["CakeName"].ToString();

            this.InputValue = ds.Tables[0].Rows[rowno]["CakeCode"].ToString();

            DataTable dtTmp = new DataTable();
            dtTmp = ds.Tables[0];

            DataTable dtBnr = ds.Tables[0].Clone();
            dtBnr.ImportRow(dtTmp.Rows[rowno]);

            //this.rptBanner.DataSource = dtBnr;
            //this.rptBanner.DataBind();

            this.rptProduct.DataSource = ds;
            this.rptProduct.DataBind();

        }
    }
}