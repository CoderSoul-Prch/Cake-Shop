﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace CakeShop
{
    public partial class Order : System.Web.UI.Page
    {
        //----------------------//
        //Define Global Varables//
        //----------------------//
        protected string strConn { get; set; }
        protected string strCakeCode { get; set; }
        protected string strProductOrderHeading { get; set; }

        SqlConnection conn;

        protected void Page_Load(object sender, EventArgs e)
        {
            //----------------------------------//
            //Get the CakeCode from Query String//
            //----------------------------------//
            strCakeCode = Request.QueryString["CakeCode"];

            //--------------------//
            //Get ConnectionString//
            //--------------------//
            strConn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString(); // ConfigurationManager.AppSettings.Get("ConnectionString");

            //-----------------------//
            //Set and Open Connection//
            //-----------------------//
            conn = new SqlConnection(strConn);
            conn.Open();

            //---------------------------------//
            //Execute SQL Command to fetch Data//
            //---------------------------------//
            SqlCommand cmd = new SqlCommand("select * from CakeMaster where CakeCode = " + strCakeCode, conn);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);

            //---------------------------//
            //Assign data to its controls//
            //---------------------------//
            this.strProductOrderHeading = ds.Tables[0].Rows[0]["CakeName"].ToString();
            this.imgProduct.AlternateText = "Image of " + ds.Tables[0].Rows[0]["CakeName"].ToString();
            this.imgProduct.ImageUrl = "ProductImg/Thumbnails/" + ds.Tables[0].Rows[0]["CakeImageName"].ToString();
            this.lblDescription.Text = ds.Tables[0].Rows[0]["CakeDescription"].ToString();
            this.orderPrice.Text = ds.Tables[0].Rows[0]["CakePrice"].ToString();
            this.orderTotal.Text = ds.Tables[0].Rows[0]["CakePrice"].ToString();

            conn.Close(); 
        }

        protected void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            //---------------------//
            //Define Local Varables//
            //---------------------//
            string strCmd = "Insert into CakeOrder(CakeCode, OrderDate, CustEmail, CustNameAddress, CakePrice, OrderQuantity, OrderTotalAmt) values(@param1,@param2,@param3,@param4,@param5,@param6,@param7)";

            //-----------------------//
            //Set and Open Connection//
            //-----------------------//
            conn = new SqlConnection(strConn);
            conn.Open();

            //----------------------------------//
            //Execute SQL Command to Insert Data//
            //----------------------------------//
            SqlCommand cmd = new SqlCommand(strCmd, conn);
            cmd.Parameters.Add("@param1", SqlDbType.Int).Value = Convert.ToInt32(strCakeCode);
            cmd.Parameters.Add("@param2", SqlDbType.DateTime).Value = DateTime.Now.Date;
            cmd.Parameters.Add("@param3", SqlDbType.VarChar, 50).Value = txtEmail.Text;
            cmd.Parameters.Add("@param4", SqlDbType.VarChar, 300).Value = txtNameAddress.Text;
            cmd.Parameters.Add("@param5", SqlDbType.Int).Value = Convert.ToInt32(orderPrice.Text);
            cmd.Parameters.Add("@param6", SqlDbType.Int).Value = Convert.ToInt32(txtQuantity.Text);
            cmd.Parameters.Add("@param7", SqlDbType.Int).Value = Convert.ToInt32(orderTotal.Text);
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            this.lStep2.Attributes["class"] = "none";
            this.lStep3.Attributes["class"] = "current";

            this.dvOrderImage.Visible = false;
            this.dvOrderGet.Visible = false;
            this.dvOrderSuccess.Visible = true;

        }
    }
}