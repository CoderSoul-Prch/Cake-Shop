﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;

namespace CakeShop
{
    public partial class Admin : System.Web.UI.Page
    {
        //----------------------//
        //Define Global Varables//
        //----------------------//
        protected string strConn { get; set; }
        protected string strProductOrderHeading { get; set; }

        SqlConnection conn;

        protected void Page_Load(object sender, EventArgs e)
        {
            //--------------------//
            //Get ConnectionString//
            //--------------------//
            strConn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString.ToString(); // ConfigurationManager.AppSettings.Get("ConnectionString");

            //-----------------------//
            //Set and Open Connection//
            //-----------------------//
            conn = new SqlConnection(strConn);
            conn.Open();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            //------------------------------//
            //Set Destination directory path//
            //------------------------------//
            string dirDestinationBanner = "ProductImg/Banners/";
            string dirDestinationThumbnail = "ProductImg/Thumbnails/";

            //-----------------------------//
            //Set Target File Name and Path//
            //-----------------------------//
            string fileName = Path.GetFileName(fuProductImage.PostedFile.FileName);
            string dirTargetBanner = (Server.MapPath(dirDestinationBanner) + fileName);
            string dirTargetThumbnail = (Server.MapPath(dirDestinationThumbnail) + fileName);

            //---------------------//
            //Define Local Varables//
            //---------------------//
            string strCmd = "Insert into CakeMaster(CakeName, CakeDescription, CakePrice, CakeImageName) values(@param1,@param2,@param3,@param4)";

            //-----------------------//
            //Set and Open Connection//
            //-----------------------//
            conn = new SqlConnection(strConn);
            conn.Open();

            //----------------------------------//
            //Execute SQL Command to Insert Data//
            //----------------------------------//
            SqlCommand cmd = new SqlCommand(strCmd, conn);
            cmd.Parameters.Add("@param1", SqlDbType.VarChar, 100).Value = txtName.Text;
            cmd.Parameters.Add("@param2", SqlDbType.VarChar, 250).Value = txtDesc.Text;
            cmd.Parameters.Add("@param3", SqlDbType.Int).Value = Convert.ToInt32(txtPrice.Text);
            cmd.Parameters.Add("@param4", SqlDbType.VarChar, 50).Value = fileName;
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            //-------------------------------------------//
            //Save file into Banner & Thumbnail directory//
            //-------------------------------------------//
            fuProductImage.SaveAs(dirTargetBanner);
            fuProductImage.SaveAs(dirTargetThumbnail);

            //this.txtAlert.Text = "Your product was saved. View it in your shop website!";
            string script = "alert(\"Your product was saved. View it in your shop website!\");";
            ScriptManager.RegisterStartupScript(this, GetType(),
                                  "ServerControlScript", script, true);

            this.txtName.Text = "";
            this.txtDesc.Text = "";
            this.txtPrice.Text = "";
            this.fuProductImage.Attributes.Clear();


        }
    }
}